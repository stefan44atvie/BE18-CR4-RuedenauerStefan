<?php
    require "db_connect.php";

    if($_POST){
            $firstname = $_POST["author_first_name"];
            $lastname = $_POST["author_last_name"];
            $title = $_POST["title"];
            $shortdescription = $_POST["short_description"];
            $ISBN = $_POST["ISBN"];
            $publishername = $_POST["publisher_name"];
            $publisheraddress = $_POST["publisher_address"];
            $publishdate = $_POST["publish_date"];
            $type = $_POST["type"];
            $status = $_POST["status"];
            $image = $_POST["image"];
            $auswahl_art = $_POST["Art"];
            // echo $shortdescription;
            // echo "<br>";
            // echo $type;
       // echo $type;
        // $sql2 = "INSERT INTO `type`(`type`) VALUES ('','')";
       // $sql1 = "INSERT INTO books(title, author_first_name, author_last_name, image, short_description, ISBN, publisher_name, publisher_address, publish_date) VALUES ($title, $firstname, $lastname, $image, $shortdescription, $ISBN, $publishername, $publisheraddress, $publishdate)";
       
       $sql2 = 'INSERT INTO `books`(title) VALUES (`$title`)';
       // echo $sql2;
       
        //echo "TESTAL";
        //$result = mysqli_query ($connect, $sql1);
        // if(mysqli_query($connect,$sql1)){
        //     echo "erfold";
        // }else{
        //     echo "Leider nichts";
        // }

        if(mysqli_query($connect,$sql2)){
            echo "erfold";
        }else{
            echo "Leider nichts";
        }

        
    


    }
?>