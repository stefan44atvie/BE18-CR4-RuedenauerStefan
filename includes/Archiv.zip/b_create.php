<?php
require_once 'db_connect.php';

if ($_POST) {   
    $firstname = $_POST["author_first_name"];
    $lastname = $_POST["author_last_name"];
    $title = $_POST["title"];
    $shortdescription = $_POST["short_description"];
    $ISBN = $_POST["ISBN"];
    $publishername = $_POST["publisher_name"];
    $publisheraddress = $_POST["publisher_address"];
    $publishdate = $_POST["publish_date"];
    $type = $_POST["type"];
    $status = $_POST["status"];
    $image = $_POST["image"];
    $auswahl_art = $_POST["Art"];
    //this function exists in the service file upload.
    $sql1 = "INSERT INTO books(title, image, ISBN, short_description, author_first_name, author_last_name, publisher_name, publisher_address, publish_date) 
    VALUES ($title,$image,$ISBN,$shortdescription,$firstname,$lastname,$publishername,$publisheraddress,$publishdate)";


    if (mysqli_query($connect, $sql1) === true) {
        $class = "success";
        $message = "The entry below was successfully created <br>
            <table class='table w-50'><tr>
            <td> $name </td>
            <td> $title </td>
            </tr></table><hr>";
    } else {
        $class = "danger";
        $message = "Error while creating record. Try again: <br>" . $connect->error;
    }
    mysqli_close($connect);
} else {
    header("location: ../error.php");
}
?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <title>Update</title>
        <?php require_once '../components/boot.php'?>
    </head>
    <body>
        <div class="container">
            <div class="mt-3 mb-3">
                <h1>Create request response</h1>
            </div>
            <div class="alert alert-<?=$class;?>" role="alert">
                <p><?php echo ($message) ?? ''; ?></p>
                <p><?php echo ($uploadError) ?? ''; ?></p>
                <a href='../index.php'><button class="btn btn-primary" type='button'>Home</button></a>
            </div>
        </div>
    </body>
</html>